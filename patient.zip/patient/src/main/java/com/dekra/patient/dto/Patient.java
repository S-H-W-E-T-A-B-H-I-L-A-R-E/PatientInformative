package com.dekra.patient.dto;

import com.poiji.annotation.ExcelCellName;
import com.poiji.annotation.ExcelRow;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
public class Patient {
    @ExcelRow
    private int rowIndex;

    @ExcelCellName("age")
    private Integer age;

    @ExcelCellName("gender")
    private String gender;

    @ExcelCellName("chest_pain")
    private String chest_pain;

    @ExcelCellName("blood_pressure")
    private String blood_pressure;

    @ExcelCellName("cholesterol")
    private Integer cholesterol;

    @ExcelCellName("blood_sugar")
    private Integer bloodSugar;

    @ExcelCellName("electrocard")
    private Integer electroCard;

    @ExcelCellName("max_hearth_rate")
    private Integer maxHearthRate;

    @ExcelCellName("ind_angina")
    private Integer indAngina;

    @ExcelCellName("oldpeak")
    private Integer oldPeak;

    @ExcelCellName("thall")
    private Integer thall;

    @ExcelCellName("vessels_num")
    private Integer vesselsNum;

    @ExcelCellName("slope")
    private Integer slope;

    @ExcelCellName("covid_risk")
    private String covidRisk;




}
