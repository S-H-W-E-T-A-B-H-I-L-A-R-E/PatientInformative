package com.dekra.patient.repository;

import com.dekra.patient.entity.PatientEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PatientRepo extends JpaRepository<PatientEntity,Integer> {

    @Query(value = "SELECT * FROM patient_table WHERE covid_risk =?1", nativeQuery = true)
    List<PatientEntity> findDataByCovidRisk(String covidRisk);

    @Query(value = "SELECT * FROM patient_table WHERE gender =?1", nativeQuery = true)
    List<PatientEntity> getDataByGender(String gender);
}
