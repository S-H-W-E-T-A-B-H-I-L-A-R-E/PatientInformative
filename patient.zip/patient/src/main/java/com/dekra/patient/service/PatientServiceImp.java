package com.dekra.patient.service;

import com.dekra.patient.entity.PatientEntity;
import com.dekra.patient.repository.PatientRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PatientServiceImp implements PatientService{

    @Autowired
    PatientRepo patientRepo;

    @Override
    public List<PatientEntity> findDataByCovidRisk(String covidRisk) {

        List<PatientEntity> dataList = patientRepo.findDataByCovidRisk(covidRisk);
        if(!dataList.isEmpty())
            return dataList;
        else
            throw new  TypeNotPresentException("covidRisk", new Throwable());
    }

    @Override
    public List<PatientEntity> getAllData() {

        List<PatientEntity> dataList = patientRepo.findAll();
        if(!dataList.isEmpty())
            return dataList;
        else
            throw new  TypeNotPresentException("Data Not found", new Throwable());
    }

    @Override
    public List<PatientEntity> getDataByGender(String gender) {

        List<PatientEntity> dataList = patientRepo.getDataByGender(gender);
        if(!dataList.isEmpty())
            return dataList;
        else
            throw new  TypeNotPresentException("Gender not found", new Throwable());
    }
}

