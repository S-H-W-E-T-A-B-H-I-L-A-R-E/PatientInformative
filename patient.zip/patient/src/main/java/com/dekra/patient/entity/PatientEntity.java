package com.dekra.patient.entity;

import lombok.Data;

import javax.persistence.*;
import javax.persistence.Entity;

@Entity
@Table(name = "patient_table")
@Data
public class PatientEntity {

    @Id
    private int rowIndex;

    @Column(name="age")
    private Integer age;

    @Column(name="gender")
    private String gender;

    @Column(name="chest_pain")
    private String chest_pain;

    @Column(name="blood_pressure",length = 2048)
    private String blood_pressure;

    @Column(name="cholesterol")
    private Integer cholesterol;

    @Column(name="blood_sugar")
    private Integer bloodSugar;

    @Column(name="electrocard")
    private Integer electroCard;

    @Column(name="max_hearth_rate")
    private Integer maxHearthRate;

    @Column(name="ind_angina")
    private Integer indAngina;

    @Column(name="oldpeak")
    private Integer oldPeak;

    @Column(name="thall")
    private Integer thall;

    @Column(name="vessels_num")
    private Integer vesselsNum;

    @Column(name="slope")
    private Integer slope;

    @Column(name="covid_risk")
    private String covidRisk;


}

