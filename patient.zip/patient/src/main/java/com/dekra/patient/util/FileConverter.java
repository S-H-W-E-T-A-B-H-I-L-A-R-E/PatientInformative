package com.dekra.patient.util;

import com.dekra.patient.dto.Patient;
import com.poiji.bind.Poiji;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.List;

public class FileConverter {

    public static List<Patient> XlsToObject(MultipartFile xlsFIle) {
        File file = write(xlsFIle);
        List<Patient> patients = Poiji.fromExcel(file, Patient.class);
        return patients;


    }

    public static File write(MultipartFile multipartFile) {
        File file = new File("src/main/resources/targetFile.xls");

        try (OutputStream os = new FileOutputStream(file)) {
            os.write(multipartFile.getBytes());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }
}
