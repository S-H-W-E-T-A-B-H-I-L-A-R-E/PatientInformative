package com.dekra.patient.service;
import com.dekra.patient.entity.PatientEntity;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public interface PatientService {

    public List<PatientEntity> findDataByCovidRisk(String covidRisk) ;

    public List<PatientEntity> getAllData();

    public List<PatientEntity> getDataByGender(String gender);
}
