package com.dekra.patient.controller;
import com.dekra.patient.dto.Patient;
import com.dekra.patient.entity.PatientEntity;
import com.dekra.patient.repository.PatientRepo;
import com.dekra.patient.service.PatientService;
import com.dekra.patient.util.FileConverter;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/admin")
public class PatientController {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    PatientRepo patientRepo;

    @Autowired
    PatientService patientService;

    /**
     *  API to save the xsls file data
     * @param multipartFile multipart file as input param
     * @return void
     * @author Shweta Bhilare
     * @date 08/11/2022
     */
    @PostMapping("/save")
    public void saveData(@RequestParam(value = "file") MultipartFile multipartFile) {
        List<Patient> patients = FileConverter.XlsToObject(multipartFile);
        List<PatientEntity> patientsEnity = patients.stream().map(patient -> modelMapper.map(patient, PatientEntity.class)).collect(Collectors.toList());
        patientRepo.saveAll(patientsEnity);
    }

    /**
     *  API to fetch by covid risk
     * @param covidRisk covid risk as param
     * @return List<Patient>
     * @author Shweta Bhilare
     * @date 08/11/2022
     */
    @GetMapping ("/getDataByCovidRisk")
    public List<Patient> findDataByCovidRisk(@RequestParam String covidRisk){
        return patientService.findDataByCovidRisk(covidRisk).stream().map(data -> modelMapper.map(data, Patient.class))
                .collect(Collectors.toList());
    }
    /**
     *  API to fetch all records
     * @param
     * @return List<Patient>
     * @author Shweta Bhilare
     * @date 09/11/2022
     */
    @GetMapping ("/getAllData")
    public List<Patient> getAllData(){
        return patientService.getAllData().stream().map(data -> modelMapper.map(data, Patient.class))
                .collect(Collectors.toList());
    }
    /**
     *  API to fetch data by gender
     * @param gender as input param
     * @return List<Patient>
     * @author Shweta Bhilare
     * @date 09/11/2022
     */
    @GetMapping ("/getDataByGender")
    public List<Patient> getDataByGender(@RequestParam String gender){
        return patientService.getDataByGender(gender).stream().map(data -> modelMapper.map(data, Patient.class))
                .collect(Collectors.toList());
    }

}
